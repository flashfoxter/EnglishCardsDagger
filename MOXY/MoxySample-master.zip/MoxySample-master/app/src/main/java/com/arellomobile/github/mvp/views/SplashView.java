package com.arellomobile.github.mvp.views;

import com.arellomobile.mvp.MvpView;

/**
 * Date: 18.01.2016
 * Time: 15:39
 *
 * @author Yuri Shmakov
 */
public interface SplashView extends MvpView {
	void setAuthorized(boolean isAuthorized);
}
